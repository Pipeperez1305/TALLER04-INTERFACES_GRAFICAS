package uniandes.dpoo.taller4.interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.Collection;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListCellRenderer.UIResource;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.formdev.flatlaf.FlatLightLaf;

import uniandes.dpoo.taller4.modelo.RegistroTop10;
import uniandes.dpoo.taller4.modelo.Tablero;
import uniandes.dpoo.taller4.modelo.Top10;

@SuppressWarnings("serial")
public class Ventana_LightsOut extends JFrame{
	
	private int Tar_Width;
	private int Tar_height;
	private final int ESPACIO_ENTRE_TARJETAS = 2;
	private int taman=6;
	private Color[][] colors;
	private JDialog top_10;
	private JPanel pOpcionesNorte;
	private JPanel pTabBombillas;
	private JPanel pInfoSur;
	private JPanel botonesEste;
	private Top10 Top10 = new Top10();
	private Tablero tablero= new Tablero(taman);
	private int NoJugadas;
	private String jugador;
	private int dificultad;
	private JTextField txt_Gammer;
	private int new_tamanio;
	private int new_dificultad;
	private DefaultListModel<String> list_top_10;

public Ventana_LightsOut(){
	
	    pTabBombillas= new JPanel(){
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D)g;
        	super.paintComponent(g2d);
        	Dimension dimension = pTabBombillas.getSize();
        	int width= (int) (dimension.getWidth()-10);
        	int height= (int) (dimension.getHeight()-10);
        	//Se calcula el ancho y alto de cada casill
        	Tar_Width= width/taman;
        	Tar_height = height/taman;
        	
            for (int fila = 0; fila < taman; fila++) {
                for (int col = 0; col < taman; col++) {
                	
                	if(tablero.darTablero()[fila][col] == true) {g2d.setColor(Color.YELLOW);}
                	else {g2d.setColor(Color.LIGHT_GRAY);}
                	
                    //g.setColor(colors[row][col]);
                    int x = col * (Tar_Width + ESPACIO_ENTRE_TARJETAS);
                    int y = fila * (Tar_height + ESPACIO_ENTRE_TARJETAS);
                    g2d.fillRoundRect(x, y, Tar_Width, Tar_height,8,8);
                    Toolkit t = Toolkit.getDefaultToolkit();
                    Image imagen = t.getImage ("./data/luz.png");
                    g2d.drawImage(imagen, x+(Tar_Width/2)-25, y+(Tar_height/2)-25, this);

                    NoJugadas=tablero.darJugadas();
                }
            }
        }
    };
    
    pTabBombillas.setBackground(Color.GRAY);
    pTabBombillas.setPreferredSize(new Dimension(((Tar_Width + ESPACIO_ENTRE_TARJETAS) * taman), (Tar_height + ESPACIO_ENTRE_TARJETAS) * taman));
	
    colors = new Color[taman][taman];
    
    
    
    //PANEL DE LOS BOTONES DEL ESTE 
    
    botonesEste = new JPanel();
	botonesEste.setOpaque(true);
	botonesEste.setLayout(new GridBagLayout());
	
    
	JPanel panelBotones= new JPanel();
	panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.PAGE_AXIS));
	
	JButton Boton_Nuevo= new JButton("NUEVO");
	Boton_Nuevo.setBackground(Color.blue );
	Boton_Nuevo.setForeground(Color.WHITE);
	Boton_Nuevo.setAlignmentX(Component. CENTER_ALIGNMENT);
	Boton_Nuevo.setMinimumSize(new Dimension(20,25));
	Boton_Nuevo.setMaximumSize(new Dimension(155,25));
	Boton_Nuevo.setPreferredSize(new Dimension(120,25));
	Boton_Nuevo.addActionListener(event -> {
		jugador = JOptionPane.showInputDialog("Nombre nuevo jugador: ");
		txt_Gammer.setText(jugador);
		taman=new_tamanio;
		tablero= new Tablero(taman);
		dificultad=new_dificultad;
		tablero.desordenar(dificultad);
		pTabBombillas.repaint();
        
     });
	panelBotones.add(Boton_Nuevo);
	panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));
	
	JButton Boton_Reiniciar= new JButton("REINICIAR");
	Boton_Reiniciar.setBackground(Color.blue );
	Boton_Reiniciar.setForeground(Color.WHITE);
	Boton_Reiniciar.setAlignmentX(Component. CENTER_ALIGNMENT);
	Boton_Reiniciar.setMinimumSize(new Dimension(20,25));
	Boton_Reiniciar.setMaximumSize(new Dimension(155,25));
	Boton_Reiniciar.setPreferredSize(new Dimension(120,25));
	Boton_Reiniciar.addActionListener(event -> {
		tablero.reiniciar();
        pTabBombillas.repaint();
    });
	panelBotones.add(Boton_Reiniciar);
	panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));
	
	JButton Boton_Top_10= new JButton("TOP-10");
	Boton_Top_10.setBackground(Color.blue);
	Boton_Top_10.setForeground(Color.WHITE);
	Boton_Top_10.setAlignmentX(Component. CENTER_ALIGNMENT);
	Boton_Top_10.setMinimumSize(new Dimension(20,25));
	Boton_Top_10.setMaximumSize(new Dimension(155,25));
	Boton_Top_10.setPreferredSize(new Dimension(120,25));
	Boton_Top_10.addActionListener(event -> {

		top_10 = new JDialog();
		top_10.setTitle("TOP 10");
		top_10.setVisible(true);
		top_10.setSize(250,260);
		top_10.setLocation(600, 200);
		top_10.setLayout(new BorderLayout());
		
		//T�TULO DE LA TABLA DONDE VA A IR EL TOP-10
		
		JTextField Nombre= new JTextField ("     #                 NOMBRE         PUNTOS"); 
		Nombre.setBackground(Color.BLUE);
		Nombre.setHorizontalAlignment (JTextField.LEFT);
		Nombre.setFont(new Font("Serief",Font.BOLD|Font.ITALIC,12));
		Nombre.setForeground(Color.WHITE);
		Nombre.setEditable(false);
		top_10.add(Nombre, BorderLayout.NORTH);
		
		//LISTA DONDE VA A ESTAR EL TOP-10
		list_top_10 = new DefaultListModel<String>();
		
		JList<String> listaDatos_top10 = new JList<String>(list_top_10);
		UIResource posicion = new UIResource();
		posicion.setHorizontalAlignment(SwingConstants.CENTER);
		listaDatos_top10.setCellRenderer(posicion);
		
		//AQUI SE LE CAMBIA EL COLOR SEG�N POSICI�N
		listaDatos_top10.setCellRenderer(new ColorRenderer());
		//..
		JScrollPane scroll = new JScrollPane(listaDatos_top10);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		Collection<RegistroTop10> registros = Top10.darRegistros();
		int i=1;
		for (RegistroTop10 registro: registros) {
		
			String regis ="     " +Integer.toString(i)+".                     "+ registro.darNombre()+"                   "+Integer.toString(registro.darPuntos());
			i++;
			
			list_top_10.addElement(regis);
			
		}
		top_10.add(scroll, BorderLayout.CENTER);
    });
	panelBotones.add(Boton_Top_10);
	panelBotones.add(Box.createRigidArea(new Dimension(0, 10)));
	
	
	
	//BOTON CAMBIAR JUGADOR
	JButton Boton_CambiarJugador= new JButton("CAMBIAR JUGADOR");
	Boton_CambiarJugador.setBackground(Color.blue );
	Boton_CambiarJugador.setForeground(Color.WHITE);
	Boton_CambiarJugador.setAlignmentX(Component. CENTER_ALIGNMENT);
	Boton_CambiarJugador.setMinimumSize(new Dimension(20,25));
	Boton_CambiarJugador.setMaximumSize(new Dimension(155,25));
	Boton_CambiarJugador.setPreferredSize(new Dimension(155,25));
	Boton_CambiarJugador.addActionListener(event -> {
		
		jugador = JOptionPane.showInputDialog("Nombre nuevo jugador: ");
		txt_Gammer.setText(jugador);
		//pTabBombillas.repaint();
    });
	panelBotones.add(Boton_CambiarJugador);
	
	botonesEste.add(panelBotones);
	
	
	
	
	//PANEL DE LA INFORMACI�N DE NO.JUGADAS Y JUGADOR
	
	pInfoSur= new JPanel();
	pInfoSur.setLayout(new GridLayout(1,4));
	pInfoSur.setBackground(Color.BLUE);
	
	JTextField txt_Jugadas= new JTextField("Jugadas: ");
	txt_Jugadas.setEditable(false);
	pInfoSur.add(txt_Jugadas);
	
	JTextField txt_NoJugadas= new JTextField("0");
	txt_NoJugadas.setEditable(false);
	pInfoSur.add(txt_NoJugadas);
	
	JTextField txt_Jugador= new JTextField("Jugador: ");
	txt_Jugador.setEditable(false);
	pInfoSur.add(txt_Jugador);
	
	txt_Gammer= new JTextField("");
	txt_Gammer.setEditable(false);
	pInfoSur.add(txt_Gammer);
	
	
	
	
	// PANEL DE LAS OPCIONES DE TAMANIO Y DIFICULTAD
	
	pOpcionesNorte= new JPanel();
	pOpcionesNorte.setLayout(new FlowLayout());
	pOpcionesNorte.setBackground(Color.BLUE);
	
	JLabel Tamanio= new JLabel("Tama�o: ");
	Tamanio.setForeground(Color.WHITE);
	pOpcionesNorte.add(Tamanio);
	
	String[]tamanios= {"3x3","5x5", "6x6"};
	JComboBox sel_tamanio= new JComboBox(tamanios);
	sel_tamanio.setMinimumSize(new Dimension(20,25));
	sel_tamanio.setMaximumSize(new Dimension(155,25));
	sel_tamanio.setPreferredSize(new Dimension(100,25));
	sel_tamanio.addActionListener(event -> {
		String [] tamanio= sel_tamanio.getSelectedItem().toString().split("x");
		int tam= Integer.parseInt(tamanio[0]);
		new_tamanio= tam;
        
     });
	pOpcionesNorte.add(sel_tamanio);
	
	
	JLabel Dificultad= new JLabel("Dificultad: ");
	Dificultad.setForeground(Color.WHITE);
	
	pOpcionesNorte.add(Dificultad);
	
	JRadioButton Ops_Facil= new JRadioButton("F�cil", false);
	Ops_Facil.setForeground(Color.WHITE);
	Ops_Facil.setBackground(Color.BLUE);
	Ops_Facil.addActionListener(event -> {
		new_dificultad=10;
     });
	pOpcionesNorte.add(Ops_Facil);
	
	JRadioButton Ops_Medio= new JRadioButton("Medio", false);
	Ops_Medio.setForeground(Color.WHITE);
	Ops_Medio.setBackground(Color.BLUE);
	Ops_Medio.addActionListener(event -> {
		new_dificultad=20;
     });
	pOpcionesNorte.add(Ops_Medio);
	
	JRadioButton Ops_Dificil= new JRadioButton("Dif�cil", false);
	Ops_Dificil.setForeground(Color.WHITE);
	Ops_Dificil.setBackground(Color.BLUE);
	Ops_Dificil.addActionListener(event -> {
		new_dificultad=30;
     });
	pOpcionesNorte.add(Ops_Dificil);
	
	ButtonGroup Ops_Dificultad= new ButtonGroup();
	Ops_Dificultad.add(Ops_Facil);
	Ops_Dificultad.add(Ops_Medio);
	Ops_Dificultad.add(Ops_Dificil);
	
	
	

//   LISTENER SOBRE LA POSICI�N DEL MOUSE
	
	pTabBombillas.addMouseListener(new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
            int row = e.getY() / (Tar_height + ESPACIO_ENTRE_TARJETAS);
            int col = e.getX() / (Tar_Width + ESPACIO_ENTRE_TARJETAS);
            
            if(tablero.darTablero()[row][col] == true) {colors[row][col] =Color.BLUE; tablero.jugar(row, col);txt_NoJugadas.setText(Integer.toString(NoJugadas+1));}
        	else {colors[row][col] =Color.BLACK; tablero.jugar(row, col);txt_NoJugadas.setText(Integer.toString(NoJugadas+1));}
            pTabBombillas.repaint();
            
            if (tablero.tableroIluminado()) {
            	
            	int Puntaje=tablero.calcularPuntaje();
            	if (Top10.esTop10(Puntaje)) {
            		
            		Top10.agregarRegistro(jugador, Puntaje);
            	}	
            }
        }
    });
	
	
	
	
	
	// AQUI SE CARGAN LOS REGISTROS AL TOP-10
	
	Top10.cargarRecords(new File("./data/top10.csv"));
	
	// VENTANA PRINCIPAL
	
	setLayout(new BorderLayout());
	add(pOpcionesNorte, BorderLayout.NORTH);
	add(pTabBombillas, BorderLayout.CENTER);
	add(botonesEste, BorderLayout.EAST);
	add(pInfoSur, BorderLayout.SOUTH);
	pack();
	setTitle("LightsOut");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setLocationRelativeTo(null);
	setLocation(350,80);// 
	setResizable(false);
	setVisible(true);
	setSize(800,650);
	
	
	// Esto se usa para que al cerrar la ventana se salven los resultados
	addWindowListener(new WindowAdapter()
	{
	public void windowClosing(WindowEvent e)
	{
	try {
		Top10.salvarRecords(new File("./data/top10.csv"));
	} catch (FileNotFoundException | UnsupportedEncodingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	});
	
	
	
}

public static void main (String[] args) {
	
	new Ventana_LightsOut();
	FlatLightLaf.install();
}

}

