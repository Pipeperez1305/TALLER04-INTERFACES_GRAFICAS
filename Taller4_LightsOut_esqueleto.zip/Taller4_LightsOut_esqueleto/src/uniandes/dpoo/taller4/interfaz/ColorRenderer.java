package uniandes.dpoo.taller4.interfaz;

import java.awt.Color;
import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

public class ColorRenderer extends DefaultListCellRenderer {
    
    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        // Verificar el valor del �ndice y establecer el color de fondo seg�n corresponda
        if (index==0||index==1||index==2) {
            c.setBackground(Color.GREEN);
        } else if (index==3) {
            c.setBackground(Color.ORANGE);
        } else {
            c.setBackground(Color.YELLOW);
        }
        
        return c;
    }
}
